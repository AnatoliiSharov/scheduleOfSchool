# university schedule with springboot posgresql flyway

university_schedule_with_SpringBoot_PosgreSQL_Flyway
creating a university schedule using SpringBoot PosgreSQL Flyway based on the UML class diagram created earlier

initialization by Flyway migration